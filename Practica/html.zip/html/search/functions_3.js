var searchData=
[
  ['distribucio',['distribucio',['../class_cjt__individus.html#a569a1232f6660f888176cacd07df134a',1,'Cjt_individus']]]
];
