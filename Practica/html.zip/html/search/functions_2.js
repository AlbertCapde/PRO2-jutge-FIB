var searchData=
[
  ['calcular_5fcombinacio',['calcular_combinacio',['../class_tret.html#a0b2a7bd1d845412f4fc94d0625a9e782',1,'Tret']]],
  ['cjt_5findividus',['Cjt_individus',['../class_cjt__individus.html#ace12a900a02d3b12c8067c7867618c50',1,'Cjt_individus']]],
  ['cjt_5ftrets',['Cjt_trets',['../class_cjt__trets.html#a0f3d29b433ebfa6d9680e1ee0f39279b',1,'Cjt_trets']]],
  ['combinacio_5fcrom',['combinacio_crom',['../class_cromosomes.html#a3453b58fad109a8317018f8349852d55',1,'Cromosomes']]],
  ['consultar_5fcrom',['consultar_crom',['../class_individu.html#a39942c24ef726105afe2b193494985a0',1,'Individu']]],
  ['consultar_5fcrom_5findividu',['consultar_crom_individu',['../class_cjt__individus.html#a5c98261f78513b1b008cead471d8afa5',1,'Cjt_individus']]],
  ['cromosomes',['Cromosomes',['../class_cromosomes.html#a117e49dbba6fef6e75d5ba774e1bd24a',1,'Cromosomes']]]
];
