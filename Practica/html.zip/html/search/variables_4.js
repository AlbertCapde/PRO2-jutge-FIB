var searchData=
[
  ['p',['p',['../class_bin_tree.html#afe3647af1dda90f6ddf1deee6560fcf1',1,'BinTree']]]
];
