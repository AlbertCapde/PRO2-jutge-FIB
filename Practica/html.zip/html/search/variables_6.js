var searchData=
[
  ['trets',['trets',['../class_cjt__trets.html#ab13190e3207e0e51bd78cf16b8ed5360',1,'Cjt_trets::trets()'],['../class_individu.html#a0ac8e4f21a7d491e6c8b90f267065bca',1,'Individu::trets()']]]
];
