var searchData=
[
  ['afegir',['afegir',['../class_cjt__trets.html#ad315f780dfe22f6730ee9ce9aa2b25d7',1,'Cjt_trets::afegir()'],['../class_individu.html#a09f3188549ab207ae329ddf56ae6240f',1,'Individu::afegir()']]],
  ['afegir_5findividu',['afegir_individu',['../class_tret.html#ad71b260f24c6e658970654561d4b117f',1,'Tret']]],
  ['afegir_5ftret',['afegir_tret',['../class_cjt__individus.html#a66d3e1b39b40532a2e2cff60fbf0b72a',1,'Cjt_individus']]],
  ['arbregen',['arbregen',['../class_cjt__individus.html#aa4786868783b8da4233a9b844ad376ce',1,'Cjt_individus']]]
];
