var searchData=
[
  ['calcular_5fcombinacio',['calcular_combinacio',['../class_tret.html#a0b2a7bd1d845412f4fc94d0625a9e782',1,'Tret']]],
  ['cjt_5findividus',['Cjt_individus',['../class_cjt__individus.html',1,'Cjt_individus'],['../class_cjt__individus.html#ace12a900a02d3b12c8067c7867618c50',1,'Cjt_individus::Cjt_individus()']]],
  ['cjt_5findividus_2ecc',['Cjt_individus.cc',['../_cjt__individus_8cc.html',1,'']]],
  ['cjt_5findividus_2ehh',['Cjt_individus.hh',['../_cjt__individus_8hh.html',1,'']]],
  ['cjt_5ftrets',['Cjt_trets',['../class_cjt__trets.html',1,'Cjt_trets'],['../class_cjt__trets.html#a0f3d29b433ebfa6d9680e1ee0f39279b',1,'Cjt_trets::Cjt_trets()']]],
  ['cjt_5ftrets_2ecc',['Cjt_trets.cc',['../_cjt__trets_8cc.html',1,'']]],
  ['cjt_5ftrets_2ehh',['Cjt_trets.hh',['../_cjt__trets_8hh.html',1,'']]],
  ['combinacio',['combinacio',['../class_tret.html#aa3cd7d694d507642466ccba3fe92a077',1,'Tret']]],
  ['combinacio_5fcrom',['combinacio_crom',['../class_cromosomes.html#a3453b58fad109a8317018f8349852d55',1,'Cromosomes']]],
  ['consultar_5fcrom',['consultar_crom',['../class_individu.html#a39942c24ef726105afe2b193494985a0',1,'Individu']]],
  ['consultar_5fcrom_5findividu',['consultar_crom_individu',['../class_cjt__individus.html#a5c98261f78513b1b008cead471d8afa5',1,'Cjt_individus']]],
  ['crom',['crom',['../class_cromosomes.html#a663df9407657383482e40832eca6e91a',1,'Cromosomes::crom()'],['../class_individu.html#a84ba8716c5c488ea4be7b7218bde1b93',1,'Individu::crom()']]],
  ['cromosomes',['Cromosomes',['../class_cromosomes.html',1,'Cromosomes'],['../class_cromosomes.html#a117e49dbba6fef6e75d5ba774e1bd24a',1,'Cromosomes::Cromosomes()']]],
  ['cromosomes_2ecc',['Cromosomes.cc',['../_cromosomes_8cc.html',1,'']]],
  ['cromosomes_2ehh',['Cromosomes.hh',['../_cromosomes_8hh.html',1,'']]]
];
