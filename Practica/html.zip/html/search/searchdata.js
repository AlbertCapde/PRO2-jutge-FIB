var indexSectionsWithContent =
{
  0: "abcdeilmnprtvx",
  1: "bcint",
  2: "bcipt",
  3: "abcdeilmnrtv",
  4: "acilprtx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables"
};

