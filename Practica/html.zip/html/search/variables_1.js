var searchData=
[
  ['combinacio',['combinacio',['../class_tret.html#aa3cd7d694d507642466ccba3fe92a077',1,'Tret']]],
  ['crom',['crom',['../class_cromosomes.html#a663df9407657383482e40832eca6e91a',1,'Cromosomes::crom()'],['../class_individu.html#a84ba8716c5c488ea4be7b7218bde1b93',1,'Individu::crom()']]]
];
